const rates = {
  cad: 1.356645,
  dkk: 7.01488,
  eur: 0.94258,
  gbp: 0.83411,
  nok: 10.42365,
  nzd: 1.604145,
  sek: 10.49414,
  usd: 1,
};

export default rates;
